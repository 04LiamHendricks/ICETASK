import java.util.Scanner;

public class Exercise12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter excluded numbers
        System.out.println("Enter the number of excluded numbers:");
        int count = scanner.nextInt();
        int[] excludedNumbers = new int[count];

        System.out.println("Enter the excluded numbers:");

        for (int i = 0; i < count; i++) {
            excludedNumbers[i] = scanner.nextInt();
        }

        // Get a random number excluding the specified numbers
        int randomNumber = RandomNumberGenerator.getRandom(excludedNumbers);

        // Display the result
        System.out.println("Random number (excluding specified numbers): " + randomNumber);

        scanner.close();
    }
}

