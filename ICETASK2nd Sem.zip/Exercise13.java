import java.util.Scanner;

public class Exercise13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[5];

        // Prompt user to enter 5 integers
        System.out.println("Enter 5 integers:");

        for (int i = 0; i < numbers.length; i++) {
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Clear invalid input
            }
            numbers[i] = scanner.nextInt();
        }

        // Find the GCD using the gcd method
        int result = GCDUtils.gcd(numbers);

        // Display the result
        System.out.println("The GCD of the entered numbers is: " + result);

        scanner.close();
    }
}
