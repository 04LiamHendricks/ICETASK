import java.util.HashSet;

public class Exercise14 {

    public static int[] eliminateDuplicates(int[] list) {
        // Use a HashSet to store unique elements
        HashSet<Integer> set = new HashSet<>();

        // Add elements to the HashSet (duplicates are ignored)
        for (int num : list) {
            set.add(num);
        }

        // Convert HashSet to an array
        int[] result = new int[set.size()];
        int i = 0;
        for (int num : set) {
            result[i++] = num;
        }

        return result;
    }

    public static void main(String[] args) {
        // Import Scanner for input
        java.util.Scanner input = new java.util.Scanner(System.in);

        // Read ten integers from user
        int[] list = new int[10];
        System.out.println("Enter 10 integers:");
        for (int i = 0; i < list.length; i++) {
            list[i] = input.nextInt();
        }

        // Call the eliminateDuplicates method
        int[] uniqueList = eliminateDuplicates(list);

        // Display the results
        System.out.print("Array after eliminating duplicates: ");
        for (int num : uniqueList) {
            System.out.print(num + " ");
        }

        // Close the scanner
        input.close();
    }
}

