import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Exercise15 {

    // Define a class to hold student information
    static class Student {
        String name;
        int score;

        Student(String name, int score) {
            this.name = name;
            this.score = score;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read number of students
        System.out.print("Enter the number of students: ");
        int numStudents = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Create a list to store students
        ArrayList<Student> students = new ArrayList<>();

        // Read student names and scores
        for (int i = 0; i < numStudents; i++) {
            System.out.print("Enter name of student " + (i + 1) + ": ");
            String name = scanner.nextLine();
            System.out.print("Enter score for " + name + ": ");
            int score = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            // Add the student to the list
            students.add(new Student(name, score));
        }

        // Sort students by score in descending order
        Collections.sort(students, new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                return Integer.compare(s2.score, s1.score); // Descending order
            }
        });

        // Print the sorted list of students
        System.out.println("\nStudents sorted by score in decreasing order:");
        for (Student student : students) {
            System.out.println(student.name + ": " + student.score);
        }

        // Close the scanner
        scanner.close();
    }
}
