import java.util.Scanner;

public class Exercise16 {

    // Method to perform bubble sort on an array of doubles
    public static void bubbleSort(double[] array) {
        int n = array.length;
        boolean swapped;

        // Traverse through all array elements
        for (int i = 0; i < n - 1; i++) {
            swapped = false;

            // Last i elements are already in place
            for (int j = 0; j < n - 1 - i; j++) {
                // Swap if the element found is greater than the next element
                if (array[j] > array[j + 1]) {
                    double temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }

            // If no two elements were swapped by inner loop, then break
            if (!swapped) break;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an array to store ten double numbers
        double[] numbers = new double[10];

        // Read ten double numbers from the user
        System.out.println("Enter 10 double numbers:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = scanner.nextDouble();
        }

        // Call bubbleSort to sort the array
        bubbleSort(numbers);

        // Display the sorted numbers
        System.out.println("Sorted numbers:");
        for (double num : numbers) {
            System.out.println(num);
        }

        // Close the scanner
        scanner.close();
    }
}

