import java.util.Scanner;

public class Exercise17 {

    // Method to check if the list is sorted in increasing order
    public static boolean isSorted(int[] list) {
        for (int i = 0; i < list.length - 1; i++) {
            if (list[i] > list[i + 1]) {
                return false; // List is not sorted
            }
        }
        return true; // List is sorted
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter the number of elements
        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();

        // Create an array to hold the list elements
        int[] list = new int[n];

        // Read the list elements from the user
        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < n; i++) {
            list[i] = scanner.nextInt();
        }

        // Check if the list is sorted
        boolean sorted = isSorted(list);

        // Display the result
        if (sorted) {
            System.out.println("The list is sorted in increasing order.");
        } else {
            System.out.println("The list is not sorted.");
        }

        // Close the scanner
        scanner.close();
    }
}
