public class Exercise18 {

    private static final int SIZE = 8; // Size of the chessboard

    // Method to check if it's safe to place a queen at board[row][col]
    public static boolean isSafe(int[][] board, int row, int col) {
        // Check the column
        for (int i = 0; i < row; i++) {
            if (board[i][col] == 1) {
                return false;
            }
        }

        // Check upper left diagonal
        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1) {
                return false;
            }
        }

        // Check upper right diagonal
        for (int i = row, j = col; i >= 0 && j < SIZE; i--, j++) {
            if (board[i][j] == 1) {
                return false;
            }
        }

        return true;
    }

    // Method to solve the Eight Queens problem using backtracking
    public static boolean solveNQueens(int[][] board, int row) {
        if (row >= SIZE) {
            return true; // All queens are placed
        }

        for (int col = 0; col < SIZE; col++) {
            if (isSafe(board, row, col)) {
                board[row][col] = 1; // Place queen

                if (solveNQueens(board, row + 1)) {
                    return true; // Solution found
                }

                board[row][col] = 0; // Backtrack
            }
        }

        return false; // No solution found
    }

    // Method to print the chessboard with queens
    public static void printBoard(int[][] board) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == 1) {
                    System.out.print("Q ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
    }

    // Main method to run the Eight Queens solution
    public static void main(String[] args) {
        int[][] board = new int[SIZE][SIZE]; // Initialize the chessboard

        if (solveNQueens(board, 0)) {
            printBoard(board); // Print one solution
        } else {
            System.out.println("No solution found.");
        }
    }
}

