public class Exercise19 {

    public static void main(String[] args) {
        final int NUMBER_OF_LOCKERS = 100;
        boolean[] lockers = new boolean[NUMBER_OF_LOCKERS];

        // Process each student
        for (int student = 1; student <= NUMBER_OF_LOCKERS; student++) {
            // Toggle lockers starting from locker `student` and then every `student`th locker
            for (int locker = student; locker <= NUMBER_OF_LOCKERS; locker += student) {
                lockers[locker - 1] = !lockers[locker - 1]; // Toggle the locker state
            }
        }

        // Print the open lockers
        System.out.print("Open lockers: ");
        for (int i = 0; i < NUMBER_OF_LOCKERS; i++) {
            if (lockers[i]) {
                System.out.print((i + 1) + " ");
            }
        }
    }
}
