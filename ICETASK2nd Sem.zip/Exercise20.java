import java.util.*;

public class Exercise20 {

    // Card class representing a card with rank and suit
    static class Card {
        String rank;
        String suit;

        Card(String rank, String suit) {
            this.rank = rank;
            this.suit = suit;
        }

        @Override
        public String toString() {
            return rank + " of " + suit;
        }
    }

    // Method to generate a full deck of cards
    private static List<Card> createDeck() {
        List<Card> deck = new ArrayList<>();
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

        for (String suit : suits) {
            for (String rank : ranks) {
                deck.add(new Card(rank, suit));
            }
        }

        return deck;
    }

    // Main method to simulate the card drawing process
    public static void main(String[] args) {
        List<Card> deck = createDeck();
        Collections.shuffle(deck); // Shuffle the deck

        Set<String> seenSuits = new HashSet<>();
        List<Card> pickedCards = new ArrayList<>();
        int drawCount = 0;

        Random random = new Random();

        while (seenSuits.size() < 4) {
            // Draw a card randomly from the deck
            Card drawnCard = deck.get(random.nextInt(deck.size()));
            pickedCards.add(drawnCard);
            seenSuits.add(drawnCard.suit);
            drawCount++;
        }

        // Output results
        System.out.println("Number of picks needed: " + drawCount);
        System.out.println("Cards picked:");
        for (Card card : pickedCards) {
            System.out.println(card);
        }
    }
}

