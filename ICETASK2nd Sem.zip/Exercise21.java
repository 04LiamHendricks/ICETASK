import java.util.Scanner;

public class Exercise21 {

    // Method to check if two integer arrays are strictly identical
    public static boolean equals(int[] list1, int[] list2) {
        // Check if the lengths of the arrays are the same
        if (list1.length != list2.length) {
            return false;
        }

        // Check if each element is the same
        for (int i = 0; i < list1.length; i++) {
            if (list1[i] != list2[i]) {
                return false;
            }
        }

        return true; // Arrays are strictly identical
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the first list
        System.out.print("Enter the number of elements in the first list: ");
        int n1 = scanner.nextInt();
        int[] list1 = new int[n1];
        System.out.println("Enter the elements of the first list:");
        for (int i = 0; i < n1; i++) {
            list1[i] = scanner.nextInt();
        }

        // Prompt the user to enter the second list
        System.out.print("Enter the number of elements in the second list: ");
        int n2 = scanner.nextInt();
        int[] list2 = new int[n2];
        System.out.println("Enter the elements of the second list:");
        for (int i = 0; i < n2; i++) {
            list2[i] = scanner.nextInt();
        }

        // Check if the lists are strictly identical and display the result
        if (equals(list1, list2)) {
            System.out.println("The two lists are strictly identical.");
        } else {
            System.out.println("The two lists are not strictly identical.");
        }

        // Close the scanner
        scanner.close();
    }
}

