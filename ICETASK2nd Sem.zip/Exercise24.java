import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Exercise24 {

    // Method to generate a deck of cards with values
    private static List<Integer> createDeck() {
        List<Integer> deck = new ArrayList<>();
        // Add cards from 2 to 10, 4 times for each value
        for (int value = 2; value <= 10; value++) {
            for (int i = 0; i < 4; i++) {
                deck.add(value);
            }
        }
        // Add face cards and Ace
        deck.add(1);  // Ace
        deck.add(13); // King
        deck.add(12); // Queen
        deck.add(11); // Jack
        return deck;
    }

    // Method to pick 4 cards from the deck
    private static List<Integer> pickFourCards(List<Integer> deck) {
        List<Integer> hand = new ArrayList<>();
        Random random = new Random();
        List<Integer> tempDeck = new ArrayList<>(deck);

        for (int i = 0; i < 4; i++) {
            int index = random.nextInt(tempDeck.size());
            hand.add(tempDeck.remove(index));
        }

        return hand;
    }

    // Method to compute the sum of a list of card values
    private static int computeSum(List<Integer> cards) {
        int sum = 0;
        for (int card : cards) {
            sum += card;
        }
        return sum;
    }

    public static void main(String[] args) {
        List<Integer> deck = createDeck();
        int count = 0;
        int trials = 100000; // Number of trials to find combinations

        for (int i = 0; i < trials; i++) {
            List<Integer> hand = pickFourCards(deck);
            int sum = computeSum(hand);
            if (sum == 24) {
                count++;
            }
            deck = createDeck(); // Recreate the deck for the next trial
        }

        System.out.println("Number of picks that yield the sum of 24: " + count);
    }
}
