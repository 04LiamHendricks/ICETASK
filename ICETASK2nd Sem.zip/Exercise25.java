import java.util.Scanner;

public class Exercise25 {

    // Method to check if the array has four consecutive numbers with the same value
    public static boolean isConsecutiveFour(int[] values) {
        if (values.length < 4) {
            return false; // Not enough elements to have four consecutive numbers
        }

        // Check each element to see if there are four consecutive elements with the same value
        for (int i = 0; i <= values.length - 4; i++) {
            if (values[i] == values[i + 1] && values[i] == values[i + 2] && values[i] == values[i + 3]) {
                return true;
            }
        }

        return false;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the size of the array
        System.out.print("Enter the number of values in the series: ");
        int size = scanner.nextInt();

        // Check if the size is valid
        if (size < 4) {
            System.out.println("The series must contain at least 4 values.");
            scanner.close();
            return;
        }

        // Prompt the user to enter the elements of the array
        int[] values = new int[size];
        System.out.println("Enter the values:");
    }
}



