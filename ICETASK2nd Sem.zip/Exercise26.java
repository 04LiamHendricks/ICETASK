import java.util.Scanner;

public class Exercise26 {

    // Method to merge two sorted arrays into a new sorted array
    public static int[] merge(int[] list1, int[] list2) {
        int[] merged = new int[list1.length + list2.length];
        int i = 0, j = 0, k = 0;

        // Merge the arrays
        while (i < list1.length && j < list2.length) {
            if (list1[i] <= list2[j]) {
                merged[k++] = list1[i++];
            } else {
                merged[k++] = list2[j++];
            }
        }

        // Copy remaining elements from list1, if any
        while (i < list1.length) {
            merged[k++] = list1[i++];
        }

        // Copy remaining elements from list2, if any
        while (j < list2.length) {
            merged[k++] = list2[j++];
        }

        return merged;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the first sorted list
        System.out.print("Enter the number of elements in the first list: ");
        int size1 = scanner.nextInt();
        int[] list1 = new int[size1];
        System.out.println("Enter the elements of the first list (sorted):");
        for (int i = 0; i < size1; i++) {
            list1[i] = scanner.nextInt();
        }

        // Prompt the user to enter the second sorted list
        System.out.print("Enter the number of elements in the second list: ");
        int size2 = scanner.nextInt();
        int[] list2 = new int[size2];
        System.out.println("Enter the elements of the second list (sorted):");
        for (int i = 0; i < size2; i++) {
            list2[i] = scanner.nextInt();
        }

        // Merge the two lists and display the result
        int[] mergedList = merge(list1, list2);
        System.out.println("Merged list:");


