import java.util.Arrays;
import java.util.Scanner;

public class Exercise27 {

    // Method to return a sorted string
    public static String sort(String s) {
        // Convert the string to a character array
        char[] characters = s.toCharArray();

        // Sort the character array
        Arrays.sort(characters);

        // Convert the sorted character array back to a string
        return new String(characters);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a string
        System.out.print("Enter a string to sort: ");
        String input = scanner.nextLine();

        // Sort the string and display the result
        String sortedString = sort(input);
        System.out.println("Sorted string: " + sortedString);

        // Close the scanner
        scanner.close();
    }
}

