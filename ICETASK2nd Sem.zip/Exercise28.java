import java.util.Random;
import java.util.Scanner;

public class Exercise28 {

    // Array of words to be used in the game
    private static final String[] WORDS = {
            "java", "python", "javascript", "hangman", "programming"
    };

    // Method to randomly select a word from the array
    private static String getRandomWord() {
        Random random = new Random();
        return WORDS[random.nextInt(WORDS.length)];
    }

    // Method to display the current state of the guessed word
    private static String getDisplayWord(String word, boolean[] guessedLetters) {
        StringBuilder display = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            if (guessedLetters[word.charAt(i) - 'a']) {
                display.append(word.charAt(i));
            } else {
                display.append('*');
            }
        }
        return display.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean playAgain = true;

        while (playAgain) {
            String word = getRandomWord();
            boolean[] guessedLetters = new boolean[26]; // Array to track guessed letters
            int misses = 0;
            final int MAX_MISSES = 6; // Max number of allowed misses

            while (true) {
                System.out.println("Current word: " + getDisplayWord(word, guessedLetters));
            }
        }
    }
}

