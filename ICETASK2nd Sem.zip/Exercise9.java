import java.util.Scanner;

public class Exercise9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] userValues = new double[10];

        // Prompt user to enter 10 double values
        System.out.println("Enter 10 double values:");

        for (int i = 0; i < userValues.length; i++) {
            while (!scanner.hasNextDouble()) {
                System.out.println("Invalid input. Please enter a valid double value.");
                scanner.next(); // Clear invalid input
            }
            userValues[i] = scanner.nextDouble();
        }

        // Find the minimum value using the min method
        double minValue = ArrayUtils.min(userValues);

        // Display the minimum value
        System.out.printf("The smallest value is: %.2f%n", minValue);

        scanner.close();
    }
}
